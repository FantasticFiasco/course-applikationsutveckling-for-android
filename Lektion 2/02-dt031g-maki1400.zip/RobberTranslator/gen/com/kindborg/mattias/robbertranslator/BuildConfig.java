/** Automatically generated file. DO NOT MODIFY */
package com.kindborg.mattias.robbertranslator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}