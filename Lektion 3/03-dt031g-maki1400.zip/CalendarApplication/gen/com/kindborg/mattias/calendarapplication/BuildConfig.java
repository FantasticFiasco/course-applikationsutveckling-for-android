/** Automatically generated file. DO NOT MODIFY */
package com.kindborg.mattias.calendarapplication;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}